# PythonAnywhere Install Checklist

Use this after the repo changes are ready.

## Goal

Verify whether OpenAI is already installed in the `workforce-api` virtualenv, install or reinstall it if needed, configure secrets, and smoke test the backend integration.

## Assumptions

- virtualenv name: `workforce-api`
- project root: `~/projects_active`
- backend app exists in the Workforce repo
- PythonAnywhere is hosting the app through WSGI/uWSGI or equivalent setup

## 1) Activate virtualenv and verify Python

```bash
workon workforce-api
echo "VENV=$VIRTUAL_ENV"
which python
python -V
which pip
python -m pip -V
```

## 2) Check whether OpenAI SDK imports cleanly

```bash
python - <<'PY'
from openai import OpenAI
print("OpenAI import OK")
client = OpenAI()
print("Client init OK")
PY
```

If import fails, install it:

```bash
python -m pip install -U openai
```

## 3) Watch for local module shadowing

You previously saw a local `/home/hn3t/openai` directory on the host. Verify that imports resolve to the package inside the virtualenv, not a local shadow path.

```bash
python - <<'PY'
import openai, sys
print("openai module path:", openai.__file__)
print("python exe:", sys.executable)
PY
```

If the module path points at a local shadow directory instead of site-packages, fix that first.

## 4) Verify API key is present

```bash
python - <<'PY'
import os
print("OPENAI_API_KEY present:", bool(os.getenv("OPENAI_API_KEY")))
PY
```

If false, configure it in the environment source used by your app host.

## 5) Smoke test the Responses API directly

```bash
python - <<'PY'
from openai import OpenAI
client = OpenAI()
response = client.responses.create(
    model="gpt-5.4",
    input="Reply with: OpenAI backend smoke test passed."
)
print(response.output_text)
PY
```

## 6) Install repo dependencies if needed

From repo root:

```bash
cd ~/projects_active
python -m pip install -e .
python -m pip install -e '.[dev]'
```

Adjust if the repo uses Poetry or another package manager as the canonical path.

## 7) Apply migrations if AI persistence tables were added

```bash
cd ~/projects_active
alembic upgrade head
```

## 8) Run targeted tests

Examples:
```bash
cd ~/projects_active
PYTHONPATH=apps/api pytest -q apps/api/tests/test_ai_routes.py
PYTHONPATH=apps/api pytest -q apps/api/tests/test_ai_tools.py
PYTHONPATH=apps/api pytest -q apps/api/tests/test_ai_streaming.py
```

Adapt to actual test locations.

## 9) Restart the web app

Use the normal PythonAnywhere reload path for the configured web app.

## 10) Verify live backend health

Add a health endpoint if not present, then test:

```bash
curl -s https://YOUR-API-DOMAIN/api/v1/ai/health
```

Expected shape:
```json
{
  "ok": true,
  "provider": "openai",
  "model": "gpt-5.4"
}
```

## 11) Live chat smoke test

Verify:
- a conversation can be created,
- a user message can be sent,
- a response is returned or streamed,
- a read-only Studio tool can be called,
- audit records are created for tool activity.

## 12) Approval-path smoke test

Verify:
- a write tool creates an approval request instead of auto-executing,
- approval from the UI executes the tool,
- rejection cleanly aborts execution.

## If something fails

Check:
- PythonAnywhere web logs
- import paths
- environment variables
- local package shadowing
- migrations
- missing frontend route wiring
- missing SSE/WebSocket headers or buffering configuration

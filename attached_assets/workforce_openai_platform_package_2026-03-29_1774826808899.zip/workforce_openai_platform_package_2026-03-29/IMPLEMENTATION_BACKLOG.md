# Implementation Backlog

## Phase 1 - foundation
- [ ] Inspect repo and align AI module placement with existing patterns
- [ ] Add provider abstraction
- [ ] Add OpenAI provider using Responses API
- [ ] Add base schemas for conversation and message persistence
- [ ] Add AI router with create/list/get/send endpoints
- [ ] Add minimal read-only health endpoint
- [ ] Add read-only chat flow without Studio tools
- [ ] Add baseline tests

## Phase 2 - communication center integration
- [ ] Wire frontend Communication Center to AI endpoints
- [ ] Add streaming transport
- [ ] Render user and assistant messages
- [ ] Add provider error and retry states
- [ ] Persist and reload conversations

## Phase 3 - studio tool gateway
- [ ] Add tool registry abstraction
- [ ] Add read-only Studio tools
- [ ] Add tool policy evaluation
- [ ] Add tool receipts
- [ ] Add audit event integration
- [ ] Add tests for authorization and scope

## Phase 4 - approval flow
- [ ] Add approval model/table
- [ ] Add pending approval flow
- [ ] Add frontend approval cards
- [ ] Add approve/reject endpoints
- [ ] Add write-capable tools behind approvals
- [ ] Add tests for approval logic and audit trails

## Phase 5 - polish and hardening
- [ ] Add rate limiting
- [ ] Add observability/metrics
- [ ] Add better prompt assembly
- [ ] Add error taxonomy
- [ ] Add docs for adding new tools
- [ ] Add regression tests for prompt/tool orchestration

## Phase 6 - optional provider expansion
- [ ] Add Copilot provider stub
- [ ] Add feature flags
- [ ] Add sidecar or MCP plan
- [ ] Add provider switching tests

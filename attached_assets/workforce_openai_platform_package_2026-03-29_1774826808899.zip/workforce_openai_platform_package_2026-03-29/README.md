# Workforce OpenAI Platform Package

This package is a repo-ready handoff for adding an AI layer to the Workforce platform so that:

1. the existing frontend Communication Center can chat with OpenAI through the backend,
2. the AI can safely operate built-in Studio functions through a tool gateway,
3. the system preserves tenant isolation, RBAC, auditability, and approval flows,
4. GitHub Copilot can optionally be wired in as a secondary developer/internal provider.

## What this package is optimized for

- FastAPI backend in the Workforce repo
- Existing frontend with a Communication Center
- PythonAnywhere hosting
- Server-side API key handling
- Tool/function calling with strict execution controls
- Streamed chat responses
- Safe execution of Studio actions
- A path to optional Copilot parity through an adapter layer

## Recommended adoption order

1. Read `OPENAI_PLATFORM_ARCHITECTURE.md`
2. Use `COPILOT_MASTER_PROMPT_OPENAI_PLATFORM.md`
3. Review `COMMUNICATION_CENTER_CHAT_SPEC.md`
4. Review `STUDIO_TOOLING_AND_ASSISTANT_POLICY.md`
5. Use `PYTHONANYWHERE_INSTALL_CHECKLIST.md`
6. Apply `ENV_TEMPLATE.md`
7. Build and validate against `TEST_PLAN.md`
8. Use `IMPLEMENTATION_BACKLOG.md` for staged rollout

## Package contents

- `COPILOT_MASTER_PROMPT_OPENAI_PLATFORM.md`
  - Primary prompt to hand to Copilot so it can inspect the repo and implement the system.
- `OPENAI_PLATFORM_ARCHITECTURE.md`
  - Canonical design for providers, conversations, tools, security, and execution flow.
- `COMMUNICATION_CENTER_CHAT_SPEC.md`
  - Frontend/backend contract for the Communication Center.
- `STUDIO_TOOLING_AND_ASSISTANT_POLICY.md`
  - Rules for how the AI behaves with users and how Studio functions are exposed.
- `COPILOT_PROVIDER_OPTION.md`
  - Optional Copilot adapter strategy, including MCP-oriented guidance.
- `PYTHONANYWHERE_INSTALL_CHECKLIST.md`
  - PythonAnywhere commands and verification sequence.
- `ENV_TEMPLATE.md`
  - Suggested environment variables and configuration notes.
- `IMPLEMENTATION_BACKLOG.md`
  - A practical build order.
- `TEST_PLAN.md`
  - Acceptance criteria and test matrix.
- `examples/`
  - Non-canonical code skeletons to guide implementation.
- `workforce-openai-platform-reference.pdf`
  - Reference catalogue of the package, with usage guidance.
- `manifest.txt`
  - Simple file manifest.

## Recommended design decisions

- Use the OpenAI **Responses API** as the primary model interface.
- Use **function calling** for Studio actions.
- Keep the OpenAI API key **server-side only**.
- Treat all tenant, business, and location context as **server-authoritative**.
- Use a **provider adapter** so OpenAI is primary and Copilot is optional.
- Require **user confirmation** for destructive or privileged actions.
- Persist conversations and tool execution results with **audit events**.
- Keep the frontend thin; put all model orchestration in the backend.

## Notes

- The example files are scaffolds, not drop-in production code.
- The master Copilot prompt is intentionally strict, so Copilot modifies the repo in an auditable way.
- The package is written to align with the Workforce design direction discussed previously: modular architecture, RBAC integrity, tenant isolation, and backend-first correctness.

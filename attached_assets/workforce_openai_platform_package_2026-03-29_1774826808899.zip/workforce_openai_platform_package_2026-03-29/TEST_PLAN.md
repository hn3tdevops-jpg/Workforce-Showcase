# Test Plan

## Objective

Verify that the AI platform layer is safe, correct, and usable inside Workforce.

## Backend tests

### Provider tests
- [ ] OpenAI provider initializes when key is present
- [ ] OpenAI provider fails gracefully when key is missing
- [ ] Responses API failure maps to stable internal error shape
- [ ] Streaming yields ordered event types

### Conversation tests
- [ ] user can create conversation within authorized business
- [ ] unauthorized business/location is rejected
- [ ] user cannot read another user’s conversation without authorization
- [ ] conversation history persists correctly

### Tool policy tests
- [ ] read-only tool allowed when permission exists
- [ ] tool blocked when permission missing
- [ ] tool blocked when scope mismatches
- [ ] write tool produces approval request when policy requires it
- [ ] approved tool executes successfully
- [ ] rejected tool does not execute

### Audit tests
- [ ] write-capable tool creates audit event
- [ ] receipt links to audit event
- [ ] approval metadata is preserved

### Error handling tests
- [ ] malformed tool args return structured failure
- [ ] provider timeout returns stable message
- [ ] stream interruption does not corrupt conversation state

## Frontend tests

- [ ] create conversation from Communication Center
- [ ] send message
- [ ] render streamed assistant output
- [ ] render proposal card
- [ ] approve action
- [ ] render success receipt
- [ ] render blocked/error card
- [ ] refresh page and restore conversation

## Manual smoke tests

### Smoke 1 - simple chat
- ask a general operational question
- verify assistant reply appears

### Smoke 2 - read-only tool
- ask for open tasks in a location
- verify assistant uses search tool and returns results

### Smoke 3 - approval flow
- ask assistant to assign a task
- verify approval card appears
- approve it
- verify receipt and audit event

### Smoke 4 - blocked action
- attempt action without permission
- verify assistant clearly reports block

## Acceptance criteria

The feature is ready for controlled rollout when:
- chat works end-to-end,
- read-only tools are stable,
- write tools cannot bypass approval or authorization,
- audit trails are present,
- frontend clearly distinguishes proposed vs executed actions,
- provider outages fail safely.

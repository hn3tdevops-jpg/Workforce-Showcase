# Environment Template

Use this as a reference, not as a literal committed secret file.

## Core AI variables

```env
AI_ENABLED=true
AI_PROVIDER_DEFAULT=openai
AI_PROVIDER_COPILOT_ENABLED=false

OPENAI_API_KEY=your_openai_key
OPENAI_MODEL_CHAT=gpt-5.4
OPENAI_MODEL_FALLBACK=gpt-5.4
OPENAI_TIMEOUT_SECONDS=90
OPENAI_STREAMING_ENABLED=true
OPENAI_MAX_TOOL_CALLS_PER_TURN=8
OPENAI_REASONING_EFFORT=medium
```

## Safety and execution controls

```env
AI_TOOL_APPROVALS_ENABLED=true
AI_ALLOW_WRITE_TOOLS=true
AI_ALLOW_BULK_TOOLS=false
AI_MAX_MESSAGES_PER_CONVERSATION=200
AI_REDACT_LOG_CONTENT=true
AI_CAPTURE_USAGE=true
AI_RATE_LIMIT_PER_MINUTE=20
```

## Provider routing

```env
AI_PROVIDER_OPENAI_ENABLED=true
AI_PROVIDER_COPILOT_ENABLED=false
COPILOT_SIDECAR_URL=http://127.0.0.1:8787
```

## Observability

```env
AI_LOG_REQUEST_IDS=true
AI_LOG_TOOL_RECEIPTS=true
AI_METRICS_ENABLED=true
```

## Notes

- `OPENAI_API_KEY` must stay server-side only.
- Never ship provider secrets to the browser.
- If different environments need different models, use environment-specific overrides.
- If the repo already has a canonical settings pattern, fold these values into that pattern rather than creating an isolated config mechanism.

export type StreamEvent =
  | { type: "message.started"; messageId?: string }
  | { type: "message.delta"; delta: string; messageId?: string }
  | { type: "message.completed"; content: string; messageId?: string }
  | { type: "tool.call.proposed"; toolName: string; approvalId?: string; summary: string }
  | { type: "approval.required"; approvalId: string; toolName: string; summary: string }
  | { type: "tool.call.completed"; receiptId: string; toolName: string; status: string; resultPreview?: string }
  | { type: "tool.call.blocked"; toolName: string; reason: string }
  | { type: "error"; code: string; message: string };

export function connectConversationStream(
  url: string,
  onEvent: (event: StreamEvent) => void
) {
  const es = new EventSource(url, { withCredentials: true } as any);

  const bind = (type: StreamEvent["type"]) => {
    es.addEventListener(type, (ev: MessageEvent) => {
      onEvent({ type, ...JSON.parse(ev.data) } as StreamEvent);
    });
  };

  bind("message.started");
  bind("message.delta");
  bind("message.completed");
  bind("tool.call.proposed");
  bind("approval.required");
  bind("tool.call.completed");
  bind("tool.call.blocked");
  bind("error");

  return () => es.close();
}

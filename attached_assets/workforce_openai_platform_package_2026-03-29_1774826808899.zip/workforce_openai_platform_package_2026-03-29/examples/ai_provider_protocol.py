from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Protocol, Any


@dataclass
class AIRequest:
    conversation_id: str
    user_id: str
    business_id: str
    location_id: str | None
    system_prompt: str
    messages: list[dict[str, Any]]
    tools: list[dict[str, Any]]
    metadata: dict[str, Any]


@dataclass
class AIResponse:
    provider: str
    model: str
    content: str
    raw: dict[str, Any]
    tool_calls: list[dict[str, Any]]
    usage: dict[str, Any] | None = None


@dataclass
class AIStreamEvent:
    event_type: str
    payload: dict[str, Any]


class AIProvider(Protocol):
    def send_message(self, request: AIRequest) -> AIResponse:
        ...

    def stream_message(self, request: AIRequest) -> Iterable[AIStreamEvent]:
        ...

    def continue_with_tool_outputs(
        self,
        request: AIRequest,
        tool_outputs: list[dict[str, Any]],
    ) -> AIResponse:
        ...

    def healthcheck(self) -> dict[str, Any]:
        ...

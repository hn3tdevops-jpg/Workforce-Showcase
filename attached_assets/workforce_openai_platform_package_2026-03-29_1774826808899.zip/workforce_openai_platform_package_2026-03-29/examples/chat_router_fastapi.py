from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse

router = APIRouter(prefix="/api/v1/ai", tags=["ai"])


@router.post("/conversations")
def create_conversation(payload: dict, current_user=Depends(...)):
    # validate business/location scope here
    return {"conversation_id": "uuid", "status": "active", "provider": "openai"}


@router.get("/conversations/{conversation_id}")
def get_conversation(conversation_id: str, current_user=Depends(...)):
    # enforce ownership or authorized access
    return {"conversation_id": conversation_id, "messages": []}


@router.post("/conversations/{conversation_id}/messages")
def send_message(conversation_id: str, payload: dict, current_user=Depends(...)):
    # persist message, queue or start orchestration
    return {"message_id": "uuid", "status": "accepted"}


@router.post("/conversations/{conversation_id}/stream")
def stream_conversation(conversation_id: str, payload: dict, current_user=Depends(...)):
    def event_iter():
        yield "event: message.started\ndata: {}\n\n"
        yield "event: message.delta\ndata: {\"delta\": \"Hello\"}\n\n"
        yield "event: message.completed\ndata: {\"content\": \"Hello\"}\n\n"

    return StreamingResponse(event_iter(), media_type="text/event-stream")


@router.post("/conversations/{conversation_id}/approvals/{approval_id}")
def resolve_approval(conversation_id: str, approval_id: str, payload: dict, current_user=Depends(...)):
    decision = payload.get("decision")
    if decision not in {"approve", "reject"}:
        raise HTTPException(status_code=400, detail="Invalid decision")
    return {"approval_id": approval_id, "status": decision}

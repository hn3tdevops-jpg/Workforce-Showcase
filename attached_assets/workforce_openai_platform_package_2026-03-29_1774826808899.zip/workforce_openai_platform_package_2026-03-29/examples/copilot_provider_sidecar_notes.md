# Copilot Provider Sidecar Notes

Use this only if you choose to implement Copilot parity after OpenAI is working.

## Shape

- Node sidecar
- Auth through installed Copilot CLI
- Minimal internal HTTP API
- FastAPI main backend remains the policy owner

## Minimal responsibilities

- send prompt to Copilot SDK
- stream response back
- expose health endpoint
- never execute Workforce tools directly without handing off to the main backend policy layer

## Why a sidecar

Current Copilot SDK guidance is Node-first and technical preview. A sidecar keeps the core Python backend clean.

from __future__ import annotations

import os
import json
from typing import Iterable

from openai import OpenAI

from ai_provider_protocol import AIProvider, AIRequest, AIResponse, AIStreamEvent


class OpenAIProvider(AIProvider):
    def __init__(self) -> None:
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.model = os.getenv("OPENAI_MODEL_CHAT", "gpt-5.4")

    def _build_input(self, request: AIRequest) -> list[dict]:
        items: list[dict] = []
        items.append(
            {
                "role": "system",
                "content": [{"type": "input_text", "text": request.system_prompt}],
            }
        )
        for msg in request.messages:
            role = msg["role"]
            text = msg["content"]
            items.append(
                {
                    "role": role,
                    "content": [{"type": "input_text", "text": text}],
                }
            )
        return items

    def send_message(self, request: AIRequest) -> AIResponse:
        response = self.client.responses.create(
            model=self.model,
            input=self._build_input(request),
            tools=request.tools or None,
        )

        tool_calls = []
        for item in getattr(response, "output", []) or []:
            if getattr(item, "type", None) == "function_call":
                tool_calls.append(
                    {
                        "call_id": getattr(item, "call_id", None),
                        "name": getattr(item, "name", None),
                        "arguments": getattr(item, "arguments", None),
                    }
                )

        return AIResponse(
            provider="openai",
            model=self.model,
            content=getattr(response, "output_text", "") or "",
            raw=response.model_dump() if hasattr(response, "model_dump") else {},
            tool_calls=tool_calls,
            usage=getattr(response, "usage", None),
        )

    def stream_message(self, request: AIRequest) -> Iterable[AIStreamEvent]:
        with self.client.responses.stream(
            model=self.model,
            input=self._build_input(request),
            tools=request.tools or None,
        ) as stream:
            yield AIStreamEvent("message.started", {})
            for event in stream:
                event_type = getattr(event, "type", "unknown")
                if event_type.endswith(".delta"):
                    delta = getattr(event, "delta", "") or ""
                    yield AIStreamEvent("message.delta", {"delta": delta})
            final_response = stream.get_final_response()
            yield AIStreamEvent(
                "message.completed",
                {"content": getattr(final_response, "output_text", "") or ""},
            )

    def continue_with_tool_outputs(
        self,
        request: AIRequest,
        tool_outputs: list[dict[str, str]],
    ) -> AIResponse:
        # This is illustrative only. Production code should thread response IDs/call IDs carefully.
        followup_input = self._build_input(request)
        followup_input.extend(tool_outputs)
        response = self.client.responses.create(
            model=self.model,
            input=followup_input,
        )
        return AIResponse(
            provider="openai",
            model=self.model,
            content=getattr(response, "output_text", "") or "",
            raw=response.model_dump() if hasattr(response, "model_dump") else {},
            tool_calls=[],
            usage=getattr(response, "usage", None),
        )

    def healthcheck(self) -> dict:
        try:
            response = self.client.responses.create(
                model=self.model,
                input="Reply with OK",
            )
            return {
                "ok": True,
                "provider": "openai",
                "model": self.model,
                "output": getattr(response, "output_text", ""),
            }
        except Exception as exc:
            return {
                "ok": False,
                "provider": "openai",
                "model": self.model,
                "error": str(exc),
            }

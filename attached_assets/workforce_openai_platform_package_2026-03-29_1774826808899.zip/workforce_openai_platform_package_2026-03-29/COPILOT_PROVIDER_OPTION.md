# Optional Copilot Provider Strategy

## Recommendation

Treat **OpenAI** as the primary production provider for the platform AI experience.

Treat **GitHub Copilot** as an optional secondary provider for:
- developer/internal tooling,
- repo-aware workflows,
- engineering assistants,
- experimental parity routing.

## Why this recommendation

OpenAI is a better direct fit for the in-product Communication Center and Studio function-calling workflow.

Copilot is extremely useful, but its application-facing SDK story is still more specialized and should not delay the main platform build.

## Target architecture

Use a provider abstraction so the app does not care which provider generated the response.

```text
AIChatService
  |- OpenAIProvider        # primary
  |- CopilotProvider       # optional
```

## Suggested Copilot options

### Option A: adapter stub only
Create:
- provider interface
- configuration placeholders
- feature flags
- docs

Then defer implementation.

This is the safest option.

### Option B: Node sidecar using Copilot SDK
Because current Copilot SDK guidance is Node-first, create a small sidecar service that:
- authenticates through installed Copilot CLI,
- exposes a minimal internal HTTP interface,
- is used only for explicitly enabled internal or experimental flows.

FastAPI backend can call it through an internal adapter.

### Option C: MCP-oriented internal tool surface
If the goal is "Copilot can use the same tools," the durable way is to expose Workforce functions through a controlled MCP-compatible layer or a similar broker abstraction, then let Copilot consume that tool surface where supported.

## Important implementation guidance

- Do not tie production user chat UX to Copilot-specific assumptions.
- Keep provider-specific auth and lifecycle isolated from core business logic.
- Use feature flags:
  - `AI_PROVIDER_DEFAULT=openai`
  - `AI_PROVIDER_COPILOT_ENABLED=false`
- Log provider usage separately.

## Suggested provider interface

```python
class AIProvider(Protocol):
    def send_message(self, request: AIRequest) -> AIResponse: ...
    def stream_message(self, request: AIRequest) -> Iterable[AIStreamEvent]: ...
    def healthcheck(self) -> ProviderHealth: ...
```

## Suggested Copilot adapter notes

If implemented:
- prefer a separate runtime boundary,
- never require the frontend to know which provider-specific auth mechanism is in use,
- keep Studio tool policy enforcement in the Workforce backend, not in the Copilot sidecar.

## When Copilot should be used

Good fits:
- internal engineering assistant,
- repo-aware admin copilot,
- coding and implementation workflows,
- experiments with alternate provider quality.

Less ideal as the first production choice for:
- tenant-facing operational assistant inside the main product,
- tightly controlled business-side tool execution flows.

## Practical conclusion

Build the platform for provider neutrality, but ship OpenAI first.

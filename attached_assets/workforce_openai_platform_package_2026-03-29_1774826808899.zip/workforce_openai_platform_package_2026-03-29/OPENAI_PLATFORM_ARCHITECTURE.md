# OpenAI Platform Architecture for Workforce

## Objective

Add a backend-owned AI platform layer to Workforce so that the current frontend Communication Center can chat with OpenAI and the assistant can safely operate Studio functions.

## Primary recommendation

Use **OpenAI Responses API** as the primary production model integration. Keep all orchestration on the backend.

Why:
- it is the current primary interface for model responses,
- it supports text generation, conversation linkage, and tool use,
- it fits the need for structured function execution,
- it supports current and future expansion better than older chat-only patterns.

## Core architecture

```text
Frontend Communication Center
        |
        v
FastAPI AI Router
        |
        v
AIChatService
  |- ConversationRepository
  |- PromptAssembler
  |- ProviderRegistry
  |- AIToolRegistry
  |- ToolExecutionPolicy
  |- Audit/Event Logger
        |
        v
OpenAIProvider
        |
        v
OpenAI Responses API
        |
        +--> function/tool call request
                  |
                  v
            Studio Tool Gateway
                  |
                  v
      authorized internal app services
```

## Principle: backend owns truth

The model is never the authority for:
- tenant scope,
- business scope,
- location scope,
- permissions,
- side effects,
- final execution success.

The backend is always the authority.

## Recommended modules

```text
apps/api/app/
  api/routes/ai.py
  schemas/ai.py
  services/ai/
    service.py
    prompting.py
    approvals.py
    policies.py
    events.py
    providers/
      base.py
      openai_provider.py
      copilot_provider.py   # optional stub
    tools/
      registry.py
      base.py
      task_tools.py
      employee_tools.py
      unit_tools.py
      issue_tools.py
  models/
    ai_conversation.py
    ai_message.py
    ai_tool_receipt.py
    ai_approval.py
```

Adapt to the repo’s actual structure if these paths do not fit.

## Provider abstraction

Define a provider contract roughly like:

- `send_message(...) -> AIResponse`
- `stream_message(...) -> Iterator[AIStreamEvent]`
- `continue_with_tool_outputs(...) -> AIResponse`
- `healthcheck() -> ProviderHealth`
- `model_name() -> str`

This keeps business logic outside provider-specific code.

## Conversation lifecycle

### Start
1. frontend creates conversation in Communication Center,
2. backend binds it to authenticated user plus business/location context,
3. backend stores conversation metadata.

### User message
1. frontend sends message,
2. backend persists message,
3. backend assembles system prompt + conversation context + authorized tools,
4. backend calls provider.

### Tool proposal
1. provider returns tool call(s),
2. backend validates against tool registry,
3. backend enforces policy and authorization,
4. backend either executes, blocks, or requests approval.

### Final response
1. backend returns assistant message and receipts,
2. frontend renders messages, action cards, and results.

## Tool execution model

Each tool registration should include:

- `name`
- `description`
- `parameter_schema`
- `required_permissions`
- `scope_type` rules
- `risk_level`
- `requires_confirmation`
- `handler`
- `audit_event_name`
- `idempotency_key_builder`

Example registration metadata:

```python
ToolDefinition(
    name="create_task",
    description="Create a task in the current business/location scope.",
    required_permissions=["tasks.create"],
    requires_confirmation=True,
    risk_level="write",
    handler=create_task_handler,
    audit_event_name="ai.tool.create_task",
)
```

## Studio tool gateway rules

The assistant can **request** a Studio action. It cannot self-authorize it.

The gateway must:
- validate input with schema,
- derive scope from server context,
- enforce RBAC,
- log intent and outcome,
- support dry-run preview when possible,
- support approvals,
- return structured output.

## Approval policy

### Safe to auto-run
Usually read-only or low-impact:
- search/list
- fetch details
- generate suggestions
- summarize data already authorized

### Requires approval
Usually write-impact:
- create/update/delete
- assignment/reassignment
- bulk changes
- status changes with operational consequences
- anything payroll/compliance-adjacent
- anything touching sensitive employee/business data

### Should be blocked
- cross-tenant access attempts
- actions without required permissions
- ambiguous destructive actions
- raw SQL, shell, or infrastructure operations unless explicitly designed and approved as admin-only internal tools

## Suggested prompt assembly

System prompt should include:

1. identity
   - "You are Workforce AI inside the Communication Center."

2. environment
   - current business
   - current location, if any
   - current module/channel
   - user role labels
   - permission summary or capability summary

3. behavioral rules
   - be precise
   - do not fabricate
   - separate recommendations from execution
   - ask for confirmation when required
   - never claim completion before backend confirmation

4. tool rules
   - use only provided tools
   - do not infer unavailable permissions
   - prefer read-first, act-second
   - provide previews when possible

5. response rules
   - concise operational language
   - explicit mention of what was done vs what is proposed
   - include reason when action is blocked

## Persistence recommendations

### AIConversation
Fields:
- `id`
- `user_id`
- `business_id`
- `location_id`
- `channel`
- `provider`
- `title`
- `status`
- `metadata_json`
- timestamps

### AIMessage
Fields:
- `id`
- `conversation_id`
- `role`
- `content_text`
- `content_json`
- `provider_message_id`
- `tool_call_json`
- `usage_json`
- `status`
- timestamps

### AIToolReceipt
Fields:
- `id`
- `conversation_id`
- `message_id`
- `tool_name`
- `request_json`
- `result_json`
- `status`
- `approval_id`
- `audit_event_id`
- timestamps

### AIApproval
Fields:
- `id`
- `conversation_id`
- `tool_name`
- `request_json`
- `requested_by_user_id`
- `approved_by_user_id`
- `status`
- `reason`
- timestamps

## Communication Center UX

The AI experience should visibly distinguish:

- plain assistant message
- proposed action
- pending approval
- completed action
- blocked action
- error

Recommended cards:
- **Proposal card**
- **Approval card**
- **Execution receipt card**
- **Blocked action card**

## Failure handling

Design for:
- missing API key
- provider timeout
- malformed tool args
- tool execution errors
- approval expiration
- stream interruption
- partial persistence failure
- provider unavailable

The user should get a clear operational message, not a trace dump.

## Security posture

- Server-side API key only
- Server-authoritative scoping
- Per-tool RBAC
- Full audit trail
- Sanitized logs
- No unbounded tool surfaces
- No direct model access to secrets
- Rate limiting per user / tenant / route as appropriate

## Optional future expansions

- reasoning mode per message type
- prompt templates per module
- retrieval from internal docs
- file attachments in conversations
- voice chat
- assistant personas per business
- multi-provider routing
- agent evals and prompt regression tests
- MCP-connected internal services

## Recommended rollout

Phase 1:
- provider abstraction
- OpenAI provider
- basic conversation persistence
- Communication Center chat
- read-only tools

Phase 2:
- approval flow
- write tools
- audit receipts
- stream UI

Phase 3:
- Copilot adapter
- retrieval
- richer Studio tools
- admin observability

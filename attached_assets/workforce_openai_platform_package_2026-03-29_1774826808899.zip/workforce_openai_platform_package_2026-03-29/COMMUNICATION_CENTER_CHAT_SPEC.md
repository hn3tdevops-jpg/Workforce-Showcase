# Communication Center Chat Spec

## Goal

Allow the existing frontend Communication Center to chat with the backend AI service and receive:
- standard assistant replies,
- streamed partial tokens,
- proposed Studio actions,
- approval requests,
- execution receipts.

## API contract

### Create conversation

`POST /api/v1/ai/conversations`

Request:
```json
{
  "business_id": "uuid",
  "location_id": "uuid-or-null",
  "channel": "communication_center",
  "title": "optional"
}
```

Response:
```json
{
  "conversation_id": "uuid",
  "status": "active",
  "provider": "openai"
}
```

### List conversations

`GET /api/v1/ai/conversations?business_id=...&location_id=...`

### Get conversation detail

`GET /api/v1/ai/conversations/{conversation_id}`

Response should include:
- conversation metadata
- paginated or bounded message list
- approval states
- tool receipts

### Send message

`POST /api/v1/ai/conversations/{conversation_id}/messages`

Request:
```json
{
  "text": "Can you show me open tasks for building 2 and assign the top priority one to Maria if I approve it?",
  "attachments": [],
  "client_request_id": "optional-idempotency-key"
}
```

Response:
```json
{
  "message_id": "uuid",
  "status": "accepted"
}
```

### Stream response

`POST /api/v1/ai/conversations/{conversation_id}/stream`

This can accept the message inline or reference the accepted message above, depending on current repo conventions.

## Suggested SSE event model

```text
event: message.started
data: {"message_id":"...","role":"assistant"}

event: message.delta
data: {"message_id":"...","delta":"Here are the open tasks"}

event: tool.call.proposed
data: {
  "tool_name":"assign_task",
  "approval_id":"...",
  "summary":"Assign task T-104 to Maria",
  "requires_approval":true
}

event: approval.required
data: {
  "approval_id":"...",
  "tool_name":"assign_task",
  "summary":"Assign task T-104 to Maria"
}

event: tool.call.completed
data: {
  "tool_name":"search_tasks",
  "receipt_id":"...",
  "status":"succeeded",
  "result_preview":"3 tasks found"
}

event: message.completed
data: {"message_id":"...","content":"I found 3 open tasks. I can assign T-104 to Maria after you approve it."}

event: error
data: {"code":"provider_timeout","message":"The assistant timed out while generating a reply."}
```

## Frontend rendering guidance

### Message types
- user bubble
- assistant bubble
- action proposal card
- approval card
- execution receipt card
- blocked/error card

### States
- idle
- sending
- streaming
- awaiting approval
- tool running
- complete
- failed

### Suggested UI controls
- message composer
- conversation list
- conversation context badge
- provider badge
- approval approve/reject buttons
- retry button
- cancel stream button if supported

## UX rules

- Never display a destructive action as completed until receipt confirms success.
- If approval is needed, render it prominently and separately from the assistant prose.
- Tool results should be skimmable, not hidden inside long paragraphs.
- Preserve history so the user can see what the assistant proposed and what the user approved.

## Recommended frontend state shape

```ts
type ChatConversation = {
  id: string;
  businessId: string;
  locationId?: string | null;
  channel: "communication_center";
  provider: "openai" | "copilot" | string;
  status: "active" | "archived" | "error";
};

type ChatItem =
  | UserMessage
  | AssistantMessage
  | ToolProposal
  | ApprovalRequest
  | ToolReceipt
  | ErrorItem;
```

## Security and scope handling

The frontend may pass `business_id` and `location_id`, but the backend must validate them against the authenticated user’s actual access.

Frontend scope is declarative.
Backend scope is authoritative.

## Suggested frontend service layer

- `createConversation(...)`
- `listConversations(...)`
- `getConversation(...)`
- `sendMessage(...)`
- `streamConversation(...)`
- `approveAction(...)`
- `rejectAction(...)`

## Suggested acceptance criteria

- user can create and reopen conversations,
- user can stream replies,
- user can see pending approvals,
- user can approve a tool action,
- user sees execution receipt,
- unauthorized scope requests are gracefully rejected,
- refresh/reload preserves conversation history.

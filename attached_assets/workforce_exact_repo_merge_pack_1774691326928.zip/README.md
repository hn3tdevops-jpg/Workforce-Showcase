# Workforce Exact Repo Merge Pack

This package is the most repo-targeted version of the Workforce planning framework created in this conversation.

It is designed specifically for an existing Workforce-style repository that already uses:

- `HN3T_MASTER_PLAN.md`
- `PROGRESS_REPORT.md`
- `scripts/run_plan.sh`
- `.github/copilot-instructions.md`

## What this pack is for
Use this pack when you want to merge the planning/execution framework into the current repo without replacing the repo's existing conventions.

## Key additions in this version
- exact merge-plan files for `HN3T_MASTER_PLAN.md`
- exact merge-plan files for `PROGRESS_REPORT.md`
- exact merge-plan files for `.github/copilot-instructions.md`
- `scripts/run_plan.sh` alignment notes
- an exact repo install prompt for Copilot
- a repo-specific reference PDF

## Start here
1. `INSTALL_INTO_EXISTING_WORKFORCE_REPO__EXACT_CONVENTIONS.md`
2. `MERGE_PATCH_PLAN__OVERVIEW.md`
3. `reference/Workforce_Exact_Repo_Merge_Pack_Reference.pdf`
4. `COPILOT_INSTALL_INTO_CURRENT_WORKFORCE_REPO__EXACT_PROMPT.md`

## Main directories
- `docs/planning/` — reusable planning framework + Workforce Studio example docs
- `root_file_inserts/` — merge-ready inserts and planning standards
- `reference/` — guide materials and PDF
- `.github/` — planning appendix for Copilot instructions

## Best use
Merge this into the repo, then use the atomic execution prompts and decision rules against `HN3T_MASTER_PLAN.md`.

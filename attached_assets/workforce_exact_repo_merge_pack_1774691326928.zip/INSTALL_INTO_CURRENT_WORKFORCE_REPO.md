# INSTALL_INTO_CURRENT_WORKFORCE_REPO.md

## Goal

Install this planning and execution framework into the current Workforce repository **without** disturbing existing repository-specific rules.

## Assumed current repo conventions

This package assumes the repo already uses or is moving toward:

- `HN3T_MASTER_PLAN.md` as the primary implementation roadmap
- `PROGRESS_REPORT.md` for execution tracking
- `scripts/run_plan.sh` for one-task-at-a-time plan execution
- `.github/copilot-instructions.md` for Copilot repository guidance
- strong tenant isolation, RBAC, and audit/timeline requirements

## Recommended merge targets

### Root-level existing files
- `HN3T_MASTER_PLAN.md`
- `PROGRESS_REPORT.md`
- `README.md` or other documentation index
- optionally `AGENTS.md` if you want a planning appendix there too

### Repo documentation target
- `docs/planning/`

### Copilot guidance target
- `.github/copilot-instructions.md`

## Recommended merge order

1. Add `docs/planning/`
2. Add `.github/copilot-instructions-planning-appendix.md`
3. Review `root_file_inserts/` and insert or merge the pieces you want into:
   - `HN3T_MASTER_PLAN.md`
   - `PROGRESS_REPORT.md`
4. Add a link to `docs/planning/README.md` from the repo's existing docs index
5. Test the first atomic execution cycle on a small safe task

## Suggested placement

### Direct drop-in docs
- copy `docs/planning/` to repo root

### Root file inserts
Use `root_file_inserts/` as merge sources, not necessarily as final committed file names.

Examples:
- merge `root_file_inserts/HN3T_MASTER_PLAN__SECTION__WORKFORCE_STUDIO_V1__ATOMIC_EXECUTION_PLAN.md` into `HN3T_MASTER_PLAN.md`
- use `root_file_inserts/PROGRESS_REPORT_TEMPLATE.md` to standardize `PROGRESS_REPORT.md`
- use `root_file_inserts/COPILOT_EXECUTE_ATOMIC_TASK.md` and `root_file_inserts/COPILOT_EXECUTION_WRAPPERS.md` as source files for your Copilot execution prompt library

## Safe install rules

- do not overwrite existing repo-specific instructions blindly
- preserve existing build/test commands in Copilot instructions
- preserve existing tenancy and RBAC instructions
- preserve existing module boundaries and naming conventions where they are better than the generic version
- use small commits

## First recommended repo changes

1. commit `docs/planning/`
2. commit the Copilot appendix
3. merge the Workforce Studio atomic section into `HN3T_MASTER_PLAN.md`
4. standardize `PROGRESS_REPORT.md`
5. run one atomic task through `scripts/run_plan.sh`

## What not to do

- do not replace the entire existing `.github/copilot-instructions.md` wholesale
- do not delete existing master-plan content
- do not add every optional file if the repo already has a stronger local equivalent
- do not start with a large multi-file task; prove the workflow first

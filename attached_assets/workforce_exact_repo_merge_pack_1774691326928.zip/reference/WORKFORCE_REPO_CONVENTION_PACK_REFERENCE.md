# WORKFORCE_REPO_CONVENTION_PACK_REFERENCE.md

## Overview
This package is a Workforce-specific version of the planning framework. It is tuned for a repo that already uses:
- `HN3T_MASTER_PLAN.md`
- `PROGRESS_REPORT.md`
- `scripts/run_plan.sh`
- `.github/copilot-instructions.md`

## How to use the package
1. install `docs/planning/`
2. merge the `.github` planning appendix
3. use `root_file_inserts/` as merge sources for root repo files
4. use the Copilot install prompt to have Copilot perform a careful integration

## Package groups

### 1. Root guidance files
- `README.md` — quick package overview
- `INSTALL_INTO_CURRENT_WORKFORCE_REPO.md` — human install steps
- `REPO_CONVENTION_FILE_MAP.md` — where each file should land in the repo
- `COPILOT_INSTALL_INTO_CURRENT_WORKFORCE_REPO_PROMPT.md` — direct prompt for Copilot

### 2. `docs/planning/`
Long-form planning framework:
- templates
- reference docs
- Workforce Studio example outputs
- Copilot install docs

### 3. `.github/`
- `copilot-instructions-planning-appendix.md` — planning appendix to merge into repo guidance

### 4. `root_file_inserts/`
Repo-convention merge sources:
- `HN3T_MASTER_PLAN__SECTION__WORKFORCE_STUDIO_V1__ATOMIC_EXECUTION_PLAN.md`
- `HN3T_MASTER_PLAN__SECTION__WORKFORCE_STUDIO_V1__BUILD_ORDER.md`
- `PROGRESS_REPORT_TEMPLATE.md`
- `RUN_PLAN_DECISION_RULES.md`
- `PLAN_STATUS_VOCABULARY.md`
- `MASTER_PLAN_FORMAT_STANDARD.md`
- `MODULE_SPEC_TEMPLATE.md`
- `COPILOT_EXECUTE_ATOMIC_TASK.md`
- `COPILOT_EXECUTION_WRAPPERS.md`

## Correct usage
- use the `HN3T_MASTER_PLAN__SECTION__...` files as insert sources, not as literal replacements for your whole master plan
- keep existing repo-specific instructions where they are stronger
- use `PROGRESS_REPORT_TEMPLATE.md` to normalize execution tracking
- keep `docs/planning/` as the long-form planning library
- use the Copilot install prompt only after placing the package into the repo or opening it alongside the repo content

## Suggested first action
Merge the Workforce Studio atomic section into `HN3T_MASTER_PLAN.md`, then run one safe checkbox through the existing execution flow.

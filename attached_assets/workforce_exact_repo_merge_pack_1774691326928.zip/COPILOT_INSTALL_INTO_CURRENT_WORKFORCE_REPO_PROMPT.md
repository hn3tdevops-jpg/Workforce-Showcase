# COPILOT_INSTALL_INTO_CURRENT_WORKFORCE_REPO_PROMPT.md

Use this prompt inside the current Workforce repository **after** adding this package.

```text
Install the planning and execution framework from this package into the current Workforce repository using the repo's existing conventions.

Repository assumptions:
- `HN3T_MASTER_PLAN.md` is the main roadmap
- `PROGRESS_REPORT.md` is the execution tracker
- `scripts/run_plan.sh` is used for one-checkbox-at-a-time execution
- `.github/copilot-instructions.md` already exists and must be preserved
- tenant isolation, RBAC integrity, and audit/timeline discipline are non-negotiable

Goals:
- add `docs/planning/` as the planning framework folder
- merge the planning appendix into `.github/copilot-instructions.md` safely
- merge the relevant Workforce Studio sections into `HN3T_MASTER_PLAN.md`
- standardize or create `PROGRESS_REPORT.md` from the provided template if helpful
- preserve existing repository-specific build/test/runtime instructions
- avoid broad rewrites or destructive replacements

Required process:
1. review `README.md`
2. review `INSTALL_INTO_CURRENT_WORKFORCE_REPO.md`
3. review `REPO_CONVENTION_FILE_MAP.md`
4. treat `docs/planning/` as the canonical long-form planning framework
5. use `root_file_inserts/` as merge sources for root repo files
6. preserve existing repo conventions when they are more specific than the generic framework
7. make minimal, reviewable changes
8. do not overwrite `HN3T_MASTER_PLAN.md` wholesale
9. do not overwrite `.github/copilot-instructions.md` wholesale
10. do not delete existing repo planning materials unless intentionally superseded

Expected result:
- `docs/planning/` exists in repo
- `.github/copilot-instructions.md` has a planning appendix or clear reference to it
- `HN3T_MASTER_PLAN.md` contains the Workforce Studio section or another chosen module section from the package
- `PROGRESS_REPORT.md` is standardized for atomic execution
- the repo can begin using the atomic planning workflow immediately
```

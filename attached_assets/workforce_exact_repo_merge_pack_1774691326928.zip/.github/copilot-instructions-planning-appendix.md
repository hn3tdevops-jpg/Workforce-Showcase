# Planning Framework Appendix for Copilot

Use this appendix to extend an existing `.github/copilot-instructions.md` file.

## Planning and execution rules
- Treat `/docs/planning` as the source of truth for planning framework files.
- When asked to create a new module plan, start from `/docs/planning/templates/MODULE_SPEC_TEMPLATE.md`.
- When asked to convert a module spec into execution steps, follow `/docs/planning/templates/MASTER_PLAN_FORMAT_STANDARD.md`.
- When asked to execute a single task from a plan, follow `/docs/planning/templates/COPILOT_EXECUTE_ATOMIC_TASK.md`.
- Use `/docs/planning/templates/RUN_PLAN_DECISION_RULES.md` to decide whether a task should be executed, skipped, retried, or marked blocked.
- Use `/docs/planning/templates/PLAN_STATUS_VOCABULARY.md` for progress and status reporting.
- Update `PROGRESS_REPORT.md` using the template under `/docs/planning/templates/` when the repository workflow requires progress tracking.

## Workforce safety rules
- Never weaken tenant isolation.
- Never bypass RBAC.
- Prefer small, reviewable patches.
- Add focused tests with behavior changes.
- Avoid broad opportunistic refactors while executing atomic tasks.

## Studio-specific rules
- Workforce Studio v1 is design-only.
- Do not let Studio mutate live operational Workforce data in v1.
- Keep Studio data in Studio-owned tables, services, routes, and artifacts.

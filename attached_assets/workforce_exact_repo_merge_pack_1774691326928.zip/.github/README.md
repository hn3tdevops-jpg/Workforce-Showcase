# .github Planning Overlay Files

This folder contains optional Copilot-facing planning guidance for installing and using the Workforce planning framework in an existing repository.

Recommended usage:
- review `copilot-instructions-planning-appendix.md`
- merge the relevant rules into your existing `.github/copilot-instructions.md` rather than replacing it blindly
- keep repository-specific build, test, lint, and architecture guidance in your main Copilot instructions file

Files here are meant to supplement the planning framework under `/docs/planning`.

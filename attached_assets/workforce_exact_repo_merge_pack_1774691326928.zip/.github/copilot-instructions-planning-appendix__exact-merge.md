# Planning and atomic execution workflow appendix

Use this appendix to extend the current repo instructions without replacing them.

## Planning rules
- treat `HN3T_MASTER_PLAN.md` as the main execution plan source
- prefer one atomic checkbox per patch
- do not bundle future tasks into the current patch
- preserve current repo patterns and architectural constraints

## Progress rules
- keep `PROGRESS_REPORT.md` updated for each completed, skipped, or blocked atomic task
- record exact checkbox text
- record plan state and outcome code
- keep the entry concise and factual

## Patch rules
- output unified diff only when asked for plan execution
- keep patches minimal and reviewable
- reject scope creep
- reject changes that weaken tenant isolation or RBAC

## Executor behavior
- execute one unchecked checkbox at a time
- use skip/block/retry rules consistently
- do not loop indefinitely on the same task
- run focused tests when the task changes behavior

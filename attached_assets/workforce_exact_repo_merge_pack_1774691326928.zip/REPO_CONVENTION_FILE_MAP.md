# REPO_CONVENTION_FILE_MAP.md

## Purpose
Map packaged files to the most likely destination in the current Workforce repo.

## Direct placement

### Documentation
- package `docs/planning/` -> repo `docs/planning/`

### Copilot appendix
- package `.github/copilot-instructions-planning-appendix.md` -> merge into or alongside repo `.github/copilot-instructions.md`

## Merge-source files

### Master plan inserts
- `root_file_inserts/HN3T_MASTER_PLAN__SECTION__WORKFORCE_STUDIO_V1__BUILD_ORDER.md`
  - merge into repo `HN3T_MASTER_PLAN.md`

- `root_file_inserts/HN3T_MASTER_PLAN__SECTION__WORKFORCE_STUDIO_V1__ATOMIC_EXECUTION_PLAN.md`
  - merge into repo `HN3T_MASTER_PLAN.md`

### Progress file standardization
- `root_file_inserts/PROGRESS_REPORT_TEMPLATE.md`
  - use to create or normalize repo `PROGRESS_REPORT.md`

- `root_file_inserts/PROGRESS_REPORT_TEMPLATE_SHORT.md`
  - optional shorter alternative for repo `PROGRESS_REPORT.md`

### Executor prompt sources
- `root_file_inserts/COPILOT_EXECUTE_ATOMIC_TASK.md`
- `root_file_inserts/COPILOT_EXECUTION_WRAPPERS.md`
  - use as the prompt library that pairs with `scripts/run_plan.sh`

### Policy / workflow standards
- `root_file_inserts/RUN_PLAN_DECISION_RULES.md`
- `root_file_inserts/PLAN_STATUS_VOCABULARY.md`
- `root_file_inserts/MASTER_PLAN_FORMAT_STANDARD.md`
- `root_file_inserts/MODULE_SPEC_TEMPLATE.md`

### Example implementation sources
- `root_file_inserts/WORKFORCE_STUDIO_IMPLEMENTATION_SPEC.md`
- `root_file_inserts/WORKFORCE_STUDIO_COPILOT_HANDOFF.md`

## Suggested final repo shape

- `HN3T_MASTER_PLAN.md`
- `PROGRESS_REPORT.md`
- `docs/planning/...`
- `.github/copilot-instructions.md`
- optional prompt library folder if you keep execution prompts in-repo

# COPILOT_INSTALL_INTO_CURRENT_WORKFORCE_REPO.md

## Purpose
Tell Copilot how to merge this planning framework into the current Workforce repo without clobbering existing instructions.

## Copilot install strategy
- treat `docs/planning/` as the planning framework source of truth
- treat `root_file_inserts/` as merge-source material for root repo files
- merge the planning appendix into `.github/copilot-instructions.md`
- preserve the repo's current commands, service layout, environment notes, and stronger repo-specific guidance

## Best first merge
1. `docs/planning/`
2. `.github/copilot-instructions-planning-appendix.md`
3. Workforce Studio atomic plan section into `HN3T_MASTER_PLAN.md`
4. `PROGRESS_REPORT.md` template alignment

## Recommended first validation
After install, test the workflow by selecting one safe atomic checkbox and running the repo's normal execution loop around it.

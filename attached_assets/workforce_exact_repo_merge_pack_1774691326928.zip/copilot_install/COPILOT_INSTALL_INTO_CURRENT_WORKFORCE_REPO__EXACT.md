# COPILOT_INSTALL_INTO_CURRENT_WORKFORCE_REPO__EXACT.md

Use `COPILOT_INSTALL_INTO_CURRENT_WORKFORCE_REPO__EXACT_PROMPT.md` when you want Copilot to merge this framework into the current Workforce repo.

## Recommended usage
- give Copilot the prompt file
- point it at the repo root
- require unified diff output only
- review the diff before applying
- preserve current repo-specific guidance and only merge the planning framework into it

## Pair with
- `MERGE_PATCH_PLAN__OVERVIEW.md`
- `INSTALL_INTO_EXISTING_WORKFORCE_REPO__EXACT_CONVENTIONS.md`
- `reference/Workforce_Exact_Repo_Merge_Pack_Reference.pdf`

# Workforce Frontend Demo

## Goal
Build a demo-ready frontend for Workforce that proves:

1. Workforce user administration
2. Hospitable room and task operations

This frontend is for demonstration, but it should still feel like a real internal operations product.

## Recommended stack
- React
- TypeScript
- Vite

## Design goals
- dark mode first
- clean operational dashboard feel
- responsive for desktop and tablet
- fast, simple workflows
- reusable components
- clear business and location context throughout the app

## Product structure

### Workforce owns
- user administration
- roles
- permissions
- business context
- location context

### Hospitable inside Workforce owns
- room views
- room status
- task views
- task assignment
- task status updates
- inspections and issues if backend is ready

## Required screens

### 1. Dashboard
Show:
- room counts by status
- task counts by status
- selected business and location
- optional recent activity list if available

### 2. Users
Show:
- user table
- scoped role assignments
- job title label as display-only
- role assignment modal or drawer

### 3. Rooms
Show:
- room list or grid by selected location
- status badges
- room details drawer or modal
- simple room edit capability if backend supports it

### 4. Tasks
Show:
- task list grouped by status
- assign task action
- update task status action
- room reference and assignee display

## App shell
Create:
- top navigation
- sidebar
- business selector
- location selector

The selected business and location should drive the data shown on dashboard, rooms, and tasks screens.

## Technical rules
- Use environment variable `VITE_API_BASE_URL`
- Put API calls in a dedicated API client layer
- Use typed interfaces for server responses
- Use reusable UI components
- Keep routing simple and clear
- Add loading, empty, and error states
- Prefer maintainable structure over over-engineering

## Mock mode requirement
If some backend endpoints are not ready yet:
- preserve the real API shapes
- implement a mock adapter with the same response structure
- make it easy to switch between mock and live API

Suggested approach:
- `src/lib/api/` for live API functions
- `src/lib/mock/` for mock data and mock service functions
- `src/config/` for environment and feature toggles

## Data contract targets

### Users / RBAC
- GET /users
- GET /roles
- POST /users/{id}/assignments
- DELETE /users/{id}/assignments/{assignment_id}

### Rooms
- GET /locations/{location_id}/rooms
- POST /locations/{location_id}/rooms
- PATCH /rooms/{room_id}

### Tasks
- GET /locations/{location_id}/tasks
- POST /locations/{location_id}/tasks
- POST /tasks/{task_id}/assign
- POST /tasks/{task_id}/status

### Dashboard
- GET /locations/{location_id}/dashboard-summary

## Visual rules
- dark background
- clear elevated cards
- readable tables
- compact but not cramped spacing
- obvious status color treatment
- admin-product feel, not consumer app feel

## Suggested folder structure
- `src/app/`
- `src/components/`
- `src/features/dashboard/`
- `src/features/users/`
- `src/features/rooms/`
- `src/features/tasks/`
- `src/lib/api/`
- `src/lib/mock/`
- `src/context/`
- `src/types/`

## Build order
1. app shell and routing
2. business and location context
3. dashboard page
4. users page
5. rooms page
6. tasks page
7. mock/live API toggle cleanup

## Demo data expectations
If mock mode is used, seed:
- 1 business
- 2 locations
- 6 users
- 10 to 20 rooms
- 8 to 12 active tasks
- mixed room statuses
- mixed task statuses
- 1 maintenance hold
- 1 failed inspection if inspection support is present

## Final expectation
The demo should support this flow:
1. Admin views users
2. Admin assigns a scoped role
3. Manager views rooms for a location
4. Manager assigns a room task
5. Housekeeper moves task to in progress and then completed
6. Dashboard reflects the result

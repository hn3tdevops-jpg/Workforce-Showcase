# Copilot instructions for this repository

This file gives Copilot repository-specific guidance for build, test, lint, runtime setup, workspace conventions, and Workforce demo-slice development priorities.

When working inside a more specific subproject that has its own `.github/copilot-instructions.md` or `AGENTS.md`, prefer the more local file over this one.

---

## Build, test, and lint commands

Notes:
- This workspace contains multiple related services rather than a single monolith
- Most backend services are Python FastAPI apps
- Frontends may be Next.js or Vite-based and live in project subfolders

### Common backend setup
Create and activate a virtual environment:

```bash
python -m venv venv
source venv/bin/activate
```

Install package and dev extras:

```bash
pip install -e .
pip install -e '.[dev]'
```

Apply database migrations:

```bash
alembic upgrade head
```

Seed demo data when supported:

```bash
python -m app.cli.main seed-demo
```

Run a backend service locally:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Use `--reload` for iterative development when appropriate.

### Tests
Run the full test suite:

```bash
pytest -q
```

Run a targeted test file or function:

```bash
pytest tests/test_matching.py::test_preferred_comes_first -v
pytest path/to/test_file.py::test_name -q
```

### Frontend setup
Install and run:

```bash
npm install
npm run dev
```

Some frontend apps may use pnpm. Check `package.json` for the declared package manager and use that when appropriate.

Run Playwright E2E tests when present:

```bash
npm run test:e2e
```

or:

```bash
npx playwright test
```

Generate TypeScript types from OpenAPI when present:

```bash
openapi-typescript $OPS/openapi.json -o src/lib/ops.types.ts
```

### Container / infra
Start the local stack:

```bash
docker compose up -d
```

### Linting / formatting
Use Ruff when available:

```bash
ruff check .
ruff --fix .
```

### Logs and runtime helpers
Background services may be started with `nohup`.

Logs are often written under `~/logs/` with names such as:
- `workforce_8002.log`
- `hospitable_ops_8003.log`

Service control helper scripts may also exist in `~/bin`.

---

## High-level architecture

This workspace contains multiple related projects rather than one application.

### Common services
- **Workforce**: Python FastAPI backend providing workforce, scheduling, matching, and administration logic
- **Hospitable Ops**: Python FastAPI backend for operational workflows and internal tooling
- **Hospitable Web**: frontend application that consumes operational APIs and may use generated OpenAPI TypeScript types

### Development workflow
- Each service typically uses its own isolated Python virtual environment
- Backends are installed with editable installs
- Database schema changes are managed with Alembic
- Local backend development usually runs through Uvicorn
- Tests use Pytest
- Frontends may consume generated OpenAPI client types

### Repo organization conventions
This workspace may include multiple project trees such as:
- `PROJECTS_CLEAN`
- `PROJECTS_ARCHIVE`
- `projects_active`

Subprojects may include their own:
- `.github/copilot-instructions.md`
- `AGENTS.md`

Always inspect those when working in a specific service area.

---

## Key conventions and non-obvious patterns

### Canonical project root environment variables
Scripts and docs may reference canonical environment variables instead of literal paths. Prefer them when present.

- `OPS_HOME` — canonical path for hospitable-ops
- `WEB_HOME` — canonical path for hospitable-web
- `WORKFORCE_HOME` — canonical path for scheduler/workforce

### Packaging and dev extras
Use lean production installs and separate dev tooling:

```bash
pip install -e .
pip install -e '.[dev]'
```

### Migrations and demo seeding
Apply schema changes first:

```bash
alembic upgrade head
```

Then run service-specific demo seeding when supported:

```bash
python -m app.cli.main seed-demo
```

### Naming and logs
Background services often write logs under `~/logs`.

Service control scripts may exist in `~/bin`, for example:
- `services_start`
- `services_stop`

### Multiple instruction files may exist
When working inside a specific service, look for more local instructions before making changes.

---

## Where to look next

Read service-level Copilot instructions when working inside a specific project:

- `workforce/.github/copilot-instructions.md`
- `workforce_api/.github/copilot-instructions.md`
- `projects_active/.github/copilot-instructions.md`
- `packages/*/workforce/.github/copilot-instructions.md`

Also check `AGENTS.md` files in subprojects for automation-specific guidance.

---

## Edit guidance for Copilot sessions

- Prefer running commands from the service root
- Use canonical environment variables when present
- When changing migrations or database schemas, include:
  - migration steps
  - seeding steps
  - test steps
- If the full test suite is slow, prefer targeted tests first
- Preserve service-specific patterns and avoid broad cross-project refactors unless explicitly requested

---

## Service-specific instructions for Workforce backend in `projects_active`

You are working on the Workforce backend for a demo-ready slice that proves:

1. Workforce user administration
2. Hospitable room and task operations inside Workforce

### Product boundaries

#### Workforce is the system of record for
- businesses
- locations
- users
- roles
- permissions
- scoped role assignments

#### Hospitable owns
- rooms / units
- room status
- tasks
- inspections
- issues
- event logs

#### Do not build in this slice
- payroll
- timeclock
- advanced scheduling
- CRM features
- messaging / chat
- duplicated workforce scheduling logic inside hospitable workflows
- external integrations
- advanced offline sync

### Technical rules
- Preserve the existing FastAPI + SQLAlchemy + Alembic architecture
- Reuse current project structure, naming patterns, and established conventions
- Keep OpenAPI and Pydantic schemas typed and explicit
- Prefer additive changes over broad refactors
- Do not introduce a second ORM or a second API framework
- Keep migrations small and reviewable
- Add tests for each new route and service slice
- Keep responses stable and frontend-friendly

### Authorization model
- Permissions come only from roles
- Roles are BUSINESS-scoped or LOCATION-scoped
- A user can have different roles at different locations
- Job title is display-only and belongs on the user’s role assignment, not in the authorization model
- Enforce scope validation in service logic and schema validation where possible
- Reject invalid cross-business and cross-location assignments

### Required backend entities
Build or complete only what is needed for the demo slice:

- Business
- Location
- User
- Role
- Permission
- UserRoleAssignment
- Room
- Task
- Inspection
- Issue
- EventLog

### Required backend capabilities

#### User administration
- list users
- create users
- update users
- assign scoped roles
- remove scoped roles
- list roles with permissions
- return effective permissions when practical
- return user assignments in a frontend-friendly shape

#### Hospitable
- list rooms by location
- create rooms
- update rooms
- update room status
- create tasks
- list tasks by location and status
- assign tasks to users
- update task status
- record inspection result
- create issue / maintenance hold
- write event log entries for major actions

#### Dashboard
Build only enough to support a location summary endpoint with:
- room counts by status
- task counts by status
- optional recent activity if easy to include

### Demo-first priorities
Build only enough to support this demo flow:

1. Admin creates or updates a user
2. Admin assigns a role at business or location scope
3. Manager views rooms in a location
4. Manager creates or assigns a cleaning task
5. Housekeeper marks task in progress and completed
6. Inspector records inspection
7. Dashboard reflects counts by location and status

### Data model expectations

#### UserRoleAssignment
Must support at minimum:
- `id`
- `user_id`
- `business_id`
- `scope_type` enum: `BUSINESS` or `LOCATION`
- `location_id` nullable only for `BUSINESS` scope
- `role_id`
- `job_title_label` display-only
- timestamps if consistent with project patterns

Validation requirements:
- BUSINESS scope assignments must not require `location_id`
- LOCATION scope assignments must require `location_id`
- `location_id` must belong to `business_id`
- role scope must match assignment scope

#### Room
Should support at minimum:
- `id`
- `business_id`
- `location_id`
- `name` or `room_number`
- `sector` optional
- `status`
- `floor_type` optional
- `bed_summary` optional
- `notes` optional

#### Task
Should support at minimum:
- `id`
- `business_id`
- `location_id`
- `room_id`
- `task_type`
- `status`
- `assigned_user_id` nullable
- `priority` optional
- `due_at` nullable
- `notes` optional

### Status conventions

#### Room statuses
Use enums or centralized constants:
- `clean`
- `dirty`
- `ready_for_inspection`
- `inspected`
- `stayover`
- `dnd`
- `laundry_only`
- `maintenance_hold`

#### Task statuses
Use enums or centralized constants:
- `open`
- `assigned`
- `in_progress`
- `completed`
- `blocked`
- `cancelled`

### Delivery expectations
When implementing work:
- inspect existing models, routes, and services first
- follow current repo patterns before inventing new structure
- make the smallest complete vertical slice
- include migration, schemas, route wiring, service logic, and tests
- avoid placeholder stubs unless absolutely necessary
- do not leave TODO comments for core requested logic if it can be completed now

### Quality bar
- validate business/location scope relationships
- reject invalid cross-location assignments
- use enums/constants for status fields
- include timestamps where existing patterns support them
- ensure responses are frontend-friendly
- add seed/demo data support where helpful

### Preferred sequence
1. RBAC and scoped user administration
2. Room model and room endpoints
3. Task model and assignment/status endpoints
4. Inspection and issue endpoints
5. Dashboard summary endpoint
6. Seed/demo data and tests

### API targets for frontend alignment
Aim to support these endpoints or the closest equivalent matching existing repo conventions:

#### Users / RBAC
- `GET /users`
- `GET /roles`
- `POST /users/{id}/assignments`
- `DELETE /users/{id}/assignments/{assignment_id}`

#### Rooms
- `GET /locations/{location_id}/rooms`
- `POST /locations/{location_id}/rooms`
- `PATCH /rooms/{room_id}`

#### Tasks
- `GET /locations/{location_id}/tasks`
- `POST /locations/{location_id}/tasks`
- `POST /tasks/{task_id}/assign`
- `POST /tasks/{task_id}/status`

#### Dashboard
- `GET /locations/{location_id}/dashboard-summary`

---

## Priority of instructions

When multiple instruction sources exist, apply them in this order:

1. More local `.github/copilot-instructions.md` in the service being edited
2. Relevant `AGENTS.md` in the service being edited
3. This repository-wide instruction file

If instructions conflict, prefer the more local file.

Last updated: 2026-03-25

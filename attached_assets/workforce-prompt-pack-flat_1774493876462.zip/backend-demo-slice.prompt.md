# Workforce Backend Demo Slice

Implement the backend needed for a demo-ready slice of Workforce that proves:

1. user administration with scoped roles
2. hospitable room and task operations

## Goal
Build the smallest complete backend slice needed to support a live frontend demo.

## Technical constraints
- Reuse the existing FastAPI, SQLAlchemy, Alembic, and schema structure already in the repo
- Follow current naming and routing conventions
- Make incremental changes
- Do not refactor unrelated modules
- Add tests for core behavior

## Required scope: phase 1
Implement or complete the user administration slice first.

### Required models / support
- Role
- Permission
- UserRoleAssignment

### UserRoleAssignment requirements
Support these fields:
- user_id
- business_id
- scope_type enum: BUSINESS or LOCATION
- location_id nullable only for BUSINESS scope
- role_id
- job_title_label display-only

### Required routes
Add or complete routes to:
- list users with their scoped assignments
- assign a role to a user
- remove a role assignment from a user
- list roles with permissions

### Required validation
- enforce scope validation
- reject invalid business/location combinations
- reject invalid role-to-scope combinations
- ensure location belongs to business where applicable

### Required deliverables
- model updates or new models
- schemas
- service logic
- routes
- migration(s)
- tests

## Required scope: phase 2
After the RBAC slice is complete, implement the hospitable room/task slice.

### Required models / support
- Room
- Task
- EventLog

### Room fields
At minimum:
- business_id
- location_id
- name or room_number
- sector optional
- status enum
- floor_type optional
- bed_summary optional
- notes optional

### Task fields
At minimum:
- business_id
- location_id
- room_id
- task_type
- status enum
- assigned_user_id nullable
- priority optional
- due_at nullable
- notes optional

### Required routes
Add or complete routes to:
- list rooms by location
- create rooms
- update rooms
- update room status
- list tasks by location and status
- create task
- assign task
- update task status

### Event logging
Write event log entries when:
- task is created
- task is assigned
- task status changes
- room status changes

### Required deliverables
- model updates or new models
- schemas
- service logic
- routes
- migration(s)
- tests

## Demo flow to support
The final backend should support this exact flow:
1. Admin creates or updates a user
2. Admin assigns a role at business or location scope
3. Manager views rooms in a location
4. Manager creates or assigns a cleaning task
5. Housekeeper marks task in progress and completed
6. Inspector records inspection
7. Dashboard returns counts by location and status

## Keep out of scope
Do not add:
- payroll
- timeclock
- advanced scheduling
- messaging
- CRM modules
- external integrations
- advanced offline sync

## API target shape
Aim to support these endpoints or the closest equivalent matching repo conventions:

### Users / RBAC
- GET /users
- GET /roles
- POST /users/{id}/assignments
- DELETE /users/{id}/assignments/{assignment_id}

### Rooms
- GET /locations/{location_id}/rooms
- POST /locations/{location_id}/rooms
- PATCH /rooms/{room_id}

### Tasks
- GET /locations/{location_id}/tasks
- POST /locations/{location_id}/tasks
- POST /tasks/{task_id}/assign
- POST /tasks/{task_id}/status

### Dashboard
- GET /locations/{location_id}/dashboard-summary

## Important
Implement the code. Do not return only a plan.
